<?php
namespace Commerce9\Popup\Block;
class Index extends \Magento\Framework\View\Element\Template
{
}